# taking two numbers
str = input("Enter string :")
n   = input("Enter Number :")

print("n repetition of string: ", str*n)
