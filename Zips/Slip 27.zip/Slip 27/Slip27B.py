dec = 344

print("The decimal value of", dec, "is:")
print(bin(dec), "in binary.") 
print(oct(dec), "in octal.") 
print(hex(dec), "in hexadecimal.")