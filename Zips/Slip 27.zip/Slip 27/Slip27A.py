l = [(1,2), (3,4), (8,9)]

print(list(zip(*l)))