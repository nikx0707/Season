lst1=[1,2,3,5]

lst2=["SVPM","Baramati"]

t1=tuple(lst1)

t2=tuple(lst2)

t3=t1 + t2

print(t3)