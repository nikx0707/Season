// Write a ‘java’ program to display characters from ‘A’ to ‘Z’


public class Q1_A {
    public static void main(String[] args) {
        for (char i = 'A'; i <= 'Z'; i++) {
            System.out.print(i + " ");
        }
    }
}