q=[11]
q.append(10)
q.append(100)
q.append(1000)
q.append(10000)

print("Initial Queue is:",q)

print(q.pop(0))
print(q.pop(0))
print(q.pop(0))

print("After Removing elements:",q)