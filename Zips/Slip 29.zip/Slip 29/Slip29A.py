pi = 3.1415926535897931

r= 6.0

V= 4.0/3.0*pi* r**3

print('The volume of the sphere is: ',V)