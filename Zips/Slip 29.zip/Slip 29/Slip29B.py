
names = {1:'Sun' ,2:'Mon' ,4:'Wed' ,3:'Tue' ,6:'Fri' ,5:'Thur' }

#print a sorted list of the keys

print(sorted(names.keys()))

#print the sorted list with items.

print(sorted(names.items()))