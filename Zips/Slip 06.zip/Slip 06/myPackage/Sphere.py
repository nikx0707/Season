class Sphere:
    def __init__(self, radius):
        self.radius = radius

    def get_area(self):
        return 4 * 3.14 * self.radius ** 2