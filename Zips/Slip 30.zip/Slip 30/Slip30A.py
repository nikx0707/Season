s = "The TYBBACA Student is clever." 
print("Original string:")

print(s)

print("Number of occurrence of 'o' in the said string:") 
print(s.count("o"))