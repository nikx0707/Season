dict={}

n=5

for x in range(1,n+1):

    dict[x]=x*x

print(dict)